# Aahil Shipping & Logistics

A five-page React, TypeScript, Vite and Tailwind CSS application. The entry point is `src/App.tsx`.

## Pages

- `/`: Home, shipping hero, service links, company introduction and testimonials.
- `/about`: Company introduction, transportation principles and working Vision/Mission tabs.
- `/services`: Seven selectable services, with matching images, copy and enquiry links.
- `/contact`: Office details, validated enquiry form, branch locations and map.
- `/dubai-branch`: Dubai office, contact details, service network and map.

Service selection is saved in the URL, for example `/services?service=air-freight`. The selected service survives refresh and browser back/forward navigation. The site's original `.html` page URLs redirect to their corresponding React routes.

## Implementation

- Shared header, footer, buttons, image handling and section components live in `src/components/`.
- Pages live in `src/pages/`.
- Company details, service content and image references live in `src/data/site.ts`.
- Form validation and email composition live in `src/lib/enquiry.ts`.
- Responsive styles, focus states and reduced-motion support live in `src/index.css`.
- External photos and logos have a local image fallback. The main vessel image is local.
- Main navigation collapses below 960px. Content adapts at 1100px, 960px, 720px and 480px, with a 320px minimum supported width.

## Enquiry Delivery

The form validates the name, email, optional telephone, selected service and office, message length and consent. A service enquiry link preselects the service; the Dubai contact link preselects the Dubai office.

No email server or API credentials were supplied. Submission prepares a `mailto:` draft for the selected office and requests the visitor's email application. The confirmation explicitly states that the visitor must send the email. A text download and a link to reopen the email application are provided as fallbacks. Nothing claims that a message has been delivered by a backend.

For direct website delivery, connect the validated form to an authenticated server-side mail endpoint, retaining server-side validation and abuse protection.

## Deployment

Deploy the entire generated `dist/` directory, including `images/`. Vite's development server supports SPA route fallback. The repository includes deployment fallbacks for:

- Netlify: `public/_redirects`.
- Vercel: `vercel.json`.
- Apache: `public/.htaccess`, requiring `mod_rewrite` and allowed overrides.

Other hosts must serve `index.html` for non-file page routes. This is necessary for directly opening or refreshing `/about`, `/services`, `/contact` and `/dubai-branch`.

## References And Verification

The two requested reference videos were not attached to the task. The implementation uses the written specification and the public Aahil website's company copy, Poppins typography, original logo, service photos, branch details and footer attribution. The main hero vessel image is newly generated. Exact video matching cannot be verified without the videos.

The production build was verified. Route definitions, all service IDs, CTA destinations, keyboard handlers, validation logic and responsive CSS were reviewed. Browser-based clicking, visual screenshots, breakpoint testing, live map behavior, external social destinations and email-client hand-off could not be tested in the available environment.

Before production launch, review the published office details with the company, provide the reference videos for a visual comparison, and run a browser QA pass covering:

- All header, footer, breadcrumb and CTA links, including direct route refreshes.
- All seven service selections, keyboard navigation and browser history.
- Mobile menu opening, Escape, outside-click dismissal and same-page links.
- Hero arrows/dots and both testimonial selectors.
- Empty, malformed and valid contact submissions for both offices.
- Email draft opening, enquiry download and returning to edit the form.
- Back-to-top, focus visibility and reduced-motion preferences.
- Desktop, tablet and mobile widths of 1440, 1024, 768, 480, 390 and 320 pixels.
- Image loading, maps, outbound links and browser console output.