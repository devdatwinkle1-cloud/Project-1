import { useLayoutEffect, useRef } from 'react';
import { BrowserRouter, Navigate, Route, Routes, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import BackToTop from './components/BackToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import DubaiBranch from './pages/DubaiBranch';
import NotFound from './pages/NotFound';

const pageTitles: Record<string, string> = {
  '/': 'On Time, On Task, On the Move',
  '/about': 'About Us',
  '/services': 'Our Services',
  '/contact': 'Contact Us',
  '/dubai-branch': 'Dubai Branch',
};

function RouteEffects() {
  const { pathname, key, state } = useLocation();
  const previousPath = useRef(pathname);

  useLayoutEffect(() => {
    const canonicalPath = pathname.replace(/\/$/, '') || '/';
    document.title = `${pageTitles[canonicalPath] || 'Page Not Found'} | AAHIL MARITIME PVT. LTD.`;
    // Navigation links reset scroll; service tabs preserve their position.
    if (previousPath.current !== pathname || state?.scrollToTop) {
      window.scrollTo({ top: 0, behavior: 'instant' });
      document.getElementById('main-content')?.focus({ preventScroll: true });
      previousPath.current = pathname;
    }
  }, [pathname, key, state]);

  return null;
}

export default function App() {
  return (
    <BrowserRouter>
      <RouteEffects />
      <Header />
      <main id="main-content" tabIndex={-1}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/services" element={<Services />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/dubai-branch" element={<DubaiBranch />} />
          <Route path="/index.html" element={<Navigate to="/" replace />} />
          <Route path="/about.html" element={<Navigate to="/about" replace />} />
          <Route path="/service.html" element={<Navigate to="/services" replace />} />
          <Route path="/services.html" element={<Navigate to="/services" replace />} />
          <Route path="/contact.html" element={<Navigate to="/contact" replace />} />
          <Route path="/contact-us" element={<Navigate to="/contact" replace />} />
          <Route path="/dubai/*" element={<Navigate to="/dubai-branch" replace />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <Footer />
      <BackToTop />
    </BrowserRouter>
  );
}
