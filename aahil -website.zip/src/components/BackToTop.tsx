import { useEffect, useState } from 'react';
import { ChevronUp } from 'lucide-react';

export default function BackToTop() {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 350);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <button className={`back-to-top ${visible ? 'is-visible' : ''}`} aria-label="Back to top" tabIndex={visible ? 0 : -1} aria-hidden={!visible} onClick={() => {
      window.scrollTo({ top: 0, behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' });
      document.querySelector<HTMLAnchorElement>('.brand-logo')?.focus({ preventScroll: true });
    }}>
      <ChevronUp size={23} aria-hidden="true" />
    </button>
  );
}