import type { ButtonHTMLAttributes, ReactNode } from 'react';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

type ButtonProps = {
  children: ReactNode;
  to?: string;
  href?: string;
  variant?: 'teal' | 'orange' | 'outline' | 'navy';
  arrow?: boolean;
} & ButtonHTMLAttributes<HTMLButtonElement>;

export default function Button({ children, to, href, variant = 'teal', arrow = false, className = '', ...props }: ButtonProps) {
  const classes = `button button--${variant} ${className}`;
  const content = <>{children}{arrow && <ArrowRight size={16} aria-hidden="true" />}</>;

  if (to) return <Link className={classes} to={to}>{content}</Link>;
  if (href) return <a className={classes} href={href}>{content}</a>;
  return <button type="button" className={classes} {...props}>{content}</button>;
}