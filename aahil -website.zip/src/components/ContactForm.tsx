import { useEffect, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { CheckCircle2, Download, Mail } from 'lucide-react';
import { useSearchParams } from 'react-router-dom';
import { services } from '../data/site';
import { createEnquiry, validateEnquiry, type EnquiryErrors, type EnquiryValues } from '../lib/enquiry';
import Button from './Button';

type Draft = ReturnType<typeof createEnquiry>;

function Field({ name, label, required = false, error, children, wide = false }: { name: string; label: string; required?: boolean; error?: string; children: ReactNode; wide?: boolean }) {
  return <div className={`form-field ${wide ? 'form-field--wide' : ''}`}><label htmlFor={`contact-${name}`}>{label}{required && <span className="required-mark"> *</span>}</label>{children}{error && <p className="field-error" id={`error-${name}`}>{error}</p>}</div>;
}

export default function ContactForm() {
  const [params] = useSearchParams();
  const requestedService = params.get('service') || '';
  const requestedBranch = params.get('branch') === 'dubai' ? 'dubai' : 'india';
  const [values, setValues] = useState<EnquiryValues>({ name: '', email: '', phone: '', organization: '', service: services.some((service) => service.id === requestedService) ? requestedService : '', branch: requestedBranch, message: '', consent: false });
  const [errors, setErrors] = useState<EnquiryErrors>({});
  const [draft, setDraft] = useState<Draft | null>(null);
  const formRef = useRef<HTMLFormElement>(null);
  const successRef = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    setValues((previous) => ({ ...previous, branch: requestedBranch, service: services.some((service) => service.id === requestedService) ? requestedService : previous.service }));
    setDraft(null);
  }, [requestedBranch, requestedService]);

  useEffect(() => { if (draft) successRef.current?.focus(); }, [draft]);

  function update<K extends keyof EnquiryValues>(name: K, value: EnquiryValues[K]) {
    setValues((previous) => ({ ...previous, [name]: value }));
    setErrors((previous) => ({ ...previous, [name]: undefined }));
  }

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const nextErrors = validateEnquiry(values);
    setErrors(nextErrors);
    const firstInvalid = Object.keys(nextErrors)[0];
    if (firstInvalid) {
      const field = formRef.current?.elements.namedItem(firstInvalid);
      if (field instanceof HTMLElement) field.focus();
      return;
    }
    const nextDraft = createEnquiry(values);
    setDraft(nextDraft);
    // A mailto hand-off is explicit: no server delivery is implied.
    window.location.href = nextDraft.href;
  }

  function downloadEnquiry() {
    if (!draft) return;
    const blob = new Blob([`To: ${draft.recipient}\nSubject: ${draft.subject}\n\n${draft.body}`], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = 'aahil-shipping-enquiry.txt';
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  const inputProps = (name: keyof EnquiryValues) => ({ id: `contact-${name}`, name, 'aria-invalid': !!errors[name], 'aria-describedby': errors[name] ? `error-${name}` : undefined });

  if (draft) {
    return (
      <div className="contact-form form-success">
        <CheckCircle2 size={48} strokeWidth={1.4} aria-hidden="true" />
        <h2 ref={successRef} tabIndex={-1}>Your Enquiry Is Ready</h2>
        <p>Your email app has been requested to open with your message. Please select <strong>Send</strong> in your email app to deliver it to our {values.branch === 'dubai' ? 'Dubai' : 'India'} team.</p>
        <p className="success-recipient"><Mail size={17} aria-hidden="true" />{draft.recipient}</p>
        <p>If your email app did not open, try the link below or download your enquiry and email it to us. Your message has not been sent automatically.</p>
        <div className="success-actions"><Button href={draft.href} arrow>Open Email App</Button><button className="text-link" onClick={downloadEnquiry}><Download size={16} aria-hidden="true" />Download Enquiry</button></div>
        <button className="edit-enquiry" onClick={() => { setDraft(null); window.requestAnimationFrame(() => document.getElementById('contact-name')?.focus()); }}>Back to my message</button>
      </div>
    );
  }

  return (
    <form className="contact-form" onSubmit={submit} ref={formRef} noValidate>
      <h2>Send a Message</h2>
      <p className="form-intro">Tell us what you need to move. We will help you find the right solution.</p>
      {Object.values(errors).some(Boolean) && <p className="form-error-summary" role="alert">Please check the highlighted fields below.</p>}
      <div className="form-grid">
        <Field name="name" label="Full Name" required error={errors.name}><input {...inputProps('name')} type="text" autoComplete="name" placeholder="Your full name" value={values.name} onChange={(event) => update('name', event.target.value)} maxLength={100} required /></Field>
        <Field name="email" label="Email Address" required error={errors.email}><input {...inputProps('email')} type="email" autoComplete="email" placeholder="you@company.com" value={values.email} onChange={(event) => update('email', event.target.value)} maxLength={254} required /></Field>
        <Field name="phone" label="Phone Number" error={errors.phone}><input {...inputProps('phone')} type="tel" autoComplete="tel" placeholder="Include country code" value={values.phone} onChange={(event) => update('phone', event.target.value)} maxLength={25} /></Field>
        <Field name="organization" label="Company"><input {...inputProps('organization')} type="text" autoComplete="organization" placeholder="Your company name" value={values.organization} onChange={(event) => update('organization', event.target.value)} maxLength={100} /></Field>
        <Field name="service" label="Service Required" required error={errors.service}><select {...inputProps('service')} value={values.service} onChange={(event) => update('service', event.target.value)} required><option value="" disabled>Select a service</option><option value="general">General Enquiry</option>{services.map((service) => <option key={service.id} value={service.id}>{service.title}</option>)}</select></Field>
        <Field name="branch" label="Contact Office" required error={errors.branch}><select {...inputProps('branch')} value={values.branch} onChange={(event) => update('branch', event.target.value)} required><option value="india">Navi Mumbai, India</option><option value="dubai">Dubai, UAE</option></select></Field>
        <Field name="message" label="Your Message" required error={errors.message} wide><textarea {...inputProps('message')} placeholder="Tell us about your cargo, origin, destination and any specific requirements..." value={values.message} onChange={(event) => update('message', event.target.value)} rows={5} minLength={20} maxLength={2000} required /><span className="character-count">{values.message.length} / 2,000</span></Field>
        <div className="consent-field form-field--wide"><label><input {...inputProps('consent')} type="checkbox" checked={values.consent} onChange={(event) => update('consent', event.target.checked)} required /><span>I agree to be contacted about my enquiry.</span></label>{errors.consent && <p className="field-error" id="error-consent">{errors.consent}</p>}</div>
      </div>
      <Button type="submit" arrow>Send Message</Button>
      <p className="form-note">Your email app will open so you can review and send your enquiry.</p>
    </form>
  );
}