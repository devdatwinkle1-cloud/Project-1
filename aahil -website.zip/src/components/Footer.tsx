import { ChevronRight, Mail, MapPin, Phone } from 'lucide-react';
import { Link } from 'react-router-dom';
import { assets, company, navigation, services } from '../data/site';
import SocialLinks from './SocialLinks';
import SmartImage from './SmartImage';

export default function Footer() {
  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div className="footer-about">
          <Link to="/" state={{ scrollToTop: true }} className="footer-logo" aria-label="Aahil Maritime home"><SmartImage src={assets.footerLogo} fallback="/images/aahil-maritime-light.svg" alt="Aahil Maritime Pvt. Ltd." width={185} height={54} /></Link>
          <h2>About Aahil<br />SHIPPING &amp; Logistics</h2>
          <span className="footer-heading-line" />
          <p>AAHIL MARITIME PVT. LTD. is a full-service international freight forwarding and logistics company based in Navi Mumbai, INDIA.</p>
          <p className="footer-tagline">{company.tagline}</p>
          <SocialLinks light />
        </div>
        <div>
          <h2>Quick Links</h2>
          <span className="footer-heading-line" />
          <ul className="footer-links">
            {[...navigation, { label: 'Dubai Branch', to: '/dubai-branch' }].map((item) => <li key={item.to}><Link to={item.to} state={{ scrollToTop: true }}><ChevronRight size={13} aria-hidden="true" />{item.label}</Link></li>)}
          </ul>
        </div>
        <div>
          <h2>Services</h2>
          <span className="footer-heading-line" />
          <ul className="footer-links footer-service-links">
            {services.map((service) => <li key={service.id}><Link to={`/services?service=${service.id}`} state={{ scrollToTop: true }}><ChevronRight size={13} aria-hidden="true" />{service.label}</Link></li>)}
          </ul>
        </div>
        <div className="footer-branches">
          <h2>Our Branches</h2>
          <span className="footer-heading-line" />
          <div className="footer-contact"><MapPin size={19} aria-hidden="true" /><div><strong>{company.name}</strong><address>{company.address}</address></div></div>
          <a className="footer-contact" href={company.phoneHref}><Phone size={16} aria-hidden="true" /><span>{company.phone}</span></a>
          <a className="footer-contact" href={`mailto:${company.email}`}><Mail size={17} aria-hidden="true" /><span>{company.email}</span></a>
          <Link className="footer-dubai" to="/dubai-branch" state={{ scrollToTop: true }}>Explore our Dubai branch<ChevronRight size={14} aria-hidden="true" /></Link>
        </div>
      </div>
      <div className="footer-bottom">
        <div className="container footer-bottom-inner">
          <p>Copyright &copy; {new Date().getFullYear()} Aahil Maritime Pvt. Ltd. All rights reserved.</p>
          <p>Designed by <a href="https://www.saraswebtech.com/" target="_blank" rel="noopener noreferrer">Saras Webtech</a></p>
        </div>
      </div>
    </footer>
  );
}