import { useEffect, useRef, useState } from 'react';
import { ArrowUpRight, Clock3, Mail, Menu, Phone, Ship, X } from 'lucide-react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { assets, company, navigation } from '../data/site';
import SmartImage from './SmartImage';
import SocialLinks from './SocialLinks';

export default function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const toggleRef = useRef<HTMLButtonElement>(null);
  const headerRef = useRef<HTMLElement>(null);
  const location = useLocation();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => { setIsOpen(false); }, [location.pathname, location.search, location.key]);

  useEffect(() => {
    if (!isOpen) return;
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsOpen(false);
        toggleRef.current?.focus();
      }
    };
    const closeOutside = (event: PointerEvent) => {
      if (!headerRef.current?.contains(event.target as Node)) setIsOpen(false);
    };
    const closeOnResize = () => { if (window.innerWidth > 960) setIsOpen(false); };
    document.addEventListener('keydown', closeOnEscape);
    document.addEventListener('pointerdown', closeOutside);
    window.addEventListener('resize', closeOnResize);
    return () => {
      document.removeEventListener('keydown', closeOnEscape);
      document.removeEventListener('pointerdown', closeOutside);
      window.removeEventListener('resize', closeOnResize);
    };
  }, [isOpen]);

  return (
    <>
      <a href="#main-content" className="skip-link">Skip to content</a>
      <div className="topbar">
        <div className="container topbar-inner">
          <span className="topbar-intro"><Ship size={15} aria-hidden="true" /> Logistics Service Provider</span>
          <div className="topbar-contacts">
            <a className="topbar-email" href={`mailto:${company.email}`}><Mail size={13} aria-hidden="true" />{company.email}</a>
            <a href={company.mobileHref}><Phone size={12} aria-hidden="true" />{company.mobile}</a>
            <span className="topbar-hours"><Clock3 size={13} aria-hidden="true" />9:30 am to 5:30 pm</span>
          </div>
        </div>
      </div>
      <header className={`site-header${scrolled ? ' is-scrolled' : ''}`} ref={headerRef}>
        <div className="container header-inner">
          <Link to="/" state={{ scrollToTop: true }} className="brand-logo" aria-label="Aahil Maritime Pvt. Ltd. home">
            <SmartImage src={assets.logo} fallback="/images/aahil-maritime.svg" alt={company.name} width={240} height={70} loading="eager" />
          </Link>
          <nav className="desktop-nav" aria-label="Main navigation">
            {navigation.map((item) => <NavLink key={item.to} to={item.to} state={{ scrollToTop: true }} end={item.to === '/'}>{item.label}</NavLink>)}
          </nav>
          <div className="header-social"><SocialLinks /></div>
          <Link to="/dubai-branch" state={{ scrollToTop: true }} className="dubai-button">Dubai Branch<ArrowUpRight size={15} aria-hidden="true" /></Link>
          <button ref={toggleRef} className="menu-toggle" aria-label={isOpen ? 'Close navigation' : 'Open navigation'} aria-expanded={isOpen} aria-controls="mobile-navigation" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X size={26} /> : <Menu size={26} />}
          </button>
        </div>
        <nav id="mobile-navigation" className={`mobile-nav ${isOpen ? 'is-open' : ''}`} aria-label="Mobile navigation" inert={!isOpen}>
          <div className="container mobile-nav-inner">
            {navigation.map((item) => <NavLink key={item.to} to={item.to} state={{ scrollToTop: true }} end={item.to === '/'}>{item.label}<ArrowUpRight size={16} aria-hidden="true" /></NavLink>)}
            <NavLink to="/dubai-branch" state={{ scrollToTop: true }} className="mobile-dubai-link">Dubai Branch<ArrowUpRight size={16} aria-hidden="true" /></NavLink>
            <SocialLinks />
          </div>
        </nav>
      </header>
    </>
  );
}