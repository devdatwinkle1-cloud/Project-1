import { useEffect, useState } from 'react';
import { assets, company } from '../data/site';
import SmartImage from './SmartImage';
import HeroServiceRotator from './HeroServiceRotator';

const servicesTagline = 'Freight Forwarding, Sea Freight, Air Freight, Liner Agency, Project Cargo, LCL, Ware Housing & 3PL, Custom Clearance, Container Trading';
const officesTagline = 'Mumbai - Mundra - Hazira, Kandla - Ahmedabad - Raipur, Chennai - All Major ICDs';
const overseasTagline = 'Dubai - Chittagong - Dhaka';

const slides = [
  { welcome: 'Welcome to', title: 'Aahil Maritime', tagline: company.tagline, image: assets.hero, alt: 'Aahil Maritime Pvt. Ltd. wordmark', variant: 'welcome' as const },
  {
    welcome: 'Our Services',
    tagline: servicesTagline,
    image: 'https://images.pexels.com/photos/3856433/pexels-photo-3856433.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1400',
    alt: 'Aerial view of a container terminal next to the ocean',
    variant: 'services' as const,
  },
  {
    welcome: 'Our Offices',
    tagline: officesTagline,
    overseas: overseasTagline,
    image: assets.officeMap,
    alt: 'Map of India highlighting major container shipping ports and overseas branches',
    variant: 'offices' as const,
  },
];

export default function Hero() {
  const [active, setActive] = useState(0);
  const slide = slides[active];

  useEffect(() => {
    const timer = window.setInterval(() => setActive((current) => (current + 1) % slides.length), 5000);
    return () => window.clearInterval(timer);
  }, []);

  return (
    <section className="hero hero--rotating-services" aria-roledescription="carousel" aria-label="Welcome to Aahil Maritime">
      <SmartImage key={slide.image} src={slide.image} alt={slide.alt} className={`hero-image hero-image--${slide.variant}`} loading="eager" fetchPriority="high" />
      <div className="hero-shade" />
      <div className="container hero-inner">
        <div className="hero-content" key={active} aria-live="polite" aria-atomic="true">
          {slide.variant === 'welcome' ? (
            <>
              <p className="hero-welcome">{slide.welcome}</p>
              <h1>{slide.title}</h1>
              <p className="hero-tagline">{slide.tagline}</p>
            </>
          ) : (
            <>
              <p className="hero-welcome">{slide.welcome}</p>
              <h2 className="hero-list">{slide.tagline}</h2>
              {slide.overseas && <p className="hero-list hero-list--secondary">{slide.overseas}</p>}
            </>
          )}
        </div>
      </div>
      {slide.variant === 'welcome' && <HeroServiceRotator />}
      <div className="hero-dots" aria-label="Choose a slide">
        {slides.map((item, index) => <button key={item.welcome} className={index === active ? 'is-active' : ''} onClick={() => setActive(index)} aria-label={`Show slide ${index + 1}`} aria-pressed={index === active}><span /></button>)}
      </div>
    </section>
  );
}