import { useEffect, useRef, useState, type AnimationEvent } from 'react';
import { Boxes, Plane, Ship, Truck } from 'lucide-react';
import '../styles/hero-service-rotator.css';

const rotatingServices = [
  { name: 'Transportation', icon: Truck },
  { name: 'Air Freight', icon: Plane },
  { name: 'Warehousing', icon: Boxes },
  { name: 'Sea Freight', icon: Ship },
];

const HOLD_DURATION = 2600;
type RotationPhase = 'holding' | 'leaving' | 'entering';

export default function HeroServiceRotator() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [phase, setPhase] = useState<RotationPhase>('holding');
  const [reducedMotion, setReducedMotion] = useState(() =>
    typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches,
  );
  const [pageHidden, setPageHidden] = useState(() => typeof document !== 'undefined' && document.hidden);
  const [inView, setInView] = useState(true);
  const rootRef = useRef<HTMLDivElement>(null);
  const stopped = reducedMotion || pageHidden || !inView;

  useEffect(() => {
    const media = window.matchMedia('(prefers-reduced-motion: reduce)');
    const updateMotion = () => setReducedMotion(media.matches);
    const updateVisibility = () => setPageHidden(document.hidden);
    media.addEventListener('change', updateMotion);
    document.addEventListener('visibilitychange', updateVisibility);

    const observer = 'IntersectionObserver' in window
      ? new IntersectionObserver(([entry]) => setInView(entry.isIntersecting), { threshold: 0 })
      : null;
    if (rootRef.current) observer?.observe(rootRef.current);

    return () => {
      media.removeEventListener('change', updateMotion);
      document.removeEventListener('visibilitychange', updateVisibility);
      observer?.disconnect();
    };
  }, []);

  useEffect(() => {
    if (reducedMotion) setPhase('holding');
  }, [reducedMotion]);

  useEffect(() => {
    if (stopped || phase !== 'holding') return;
    const timeout = window.setTimeout(() => setPhase('leaving'), HOLD_DURATION);
    return () => window.clearTimeout(timeout);
  }, [stopped, phase]);

  function finishAnimation(event: AnimationEvent<HTMLDivElement>) {
    if (event.target !== event.currentTarget || reducedMotion) return;

    // Replace the label only after its exit finishes, so two names never overlap.
    if (phase === 'leaving' && event.animationName === 'hero-service-leave') {
      setActiveIndex((index) => (index + 1) % rotatingServices.length);
      setPhase('entering');
    } else if (phase === 'entering' && event.animationName === 'hero-service-enter') {
      setPhase('holding');
    }
  }

  const service = rotatingServices[activeIndex];
  const Icon = service.icon;

  return (
    <>
      <div className="hero-arc-mask" data-paused={stopped} aria-hidden="true">
        <div className="hero-arc-pivot">
          <svg key={activeIndex} className={`hero-arc-svg hero-arc-svg--${phase}`} viewBox="-100 -100 200 200" focusable="false">
            <path d="M50 -86.6025A100 100 0 0 0 -96.1262 -27.5637" />
            <path d="M-96.1262 27.5637A100 100 0 0 0 50 86.6025" />
          </svg>
        </div>
      </div>
      <div ref={rootRef} className="hero-service-rotator" data-paused={stopped} role="group" aria-label="Featured shipping services">
        <span className="sr-only">{rotatingServices.map((item) => item.name).join(', ')}.</span>
        <div className="hero-service-rotator__window" aria-hidden="true">
          <div key={activeIndex} className={`hero-service-rotator__item hero-service-rotator__item--${phase}`} onAnimationEnd={finishAnimation}>
            <Icon className="hero-service-rotator__icon" size={42} strokeWidth={2.3} aria-hidden="true" />
            <span className="hero-service-rotator__name">{service.name}</span>
          </div>
        </div>
      </div>
    </>
  );
}