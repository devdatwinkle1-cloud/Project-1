import { ArrowUpRight, MapPin } from 'lucide-react';

export default function LocationMap({ address, title }: { address: string; title: string }) {
  const query = encodeURIComponent(address);
  return (
    <section className="location-section" aria-label={`${title} location`}>
      <div className="container location-heading"><h2><MapPin size={21} aria-hidden="true" />{title}</h2><a href={`https://www.google.com/maps/search/?api=1&query=${query}`} target="_blank" rel="noopener noreferrer">View on Google Maps<ArrowUpRight size={16} aria-hidden="true" /></a></div>
      <iframe title={`Map showing ${title}`} src={`https://maps.google.com/maps?q=${query}&z=15&output=embed`} loading="lazy" referrerPolicy="no-referrer-when-downgrade" allowFullScreen />
    </section>
  );
}