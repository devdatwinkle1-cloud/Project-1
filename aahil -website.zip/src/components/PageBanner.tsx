import { ChevronRight, House } from 'lucide-react';
import { Link } from 'react-router-dom';
import { assets } from '../data/site';
import SmartImage from './SmartImage';

export default function PageBanner({ title, image = assets.hero, photographic = false }: { title: string; image?: string; photographic?: boolean }) {
  return (
    <section className={`page-banner${photographic ? ' page-banner--photographic' : ''}`} aria-label={title}>
      <SmartImage className="page-banner-image" src={image} alt="" loading="eager" />
      <div className="page-banner-shade" />
      <div className="container page-banner-inner">
        <h1>{title}</h1>
        <nav aria-label="Breadcrumb" className="breadcrumbs"><Link to="/"><House size={14} aria-hidden="true" />Home</Link><ChevronRight size={14} aria-hidden="true" /><span aria-current="page">{title}</span></nav>
      </div>
    </section>
  );
}