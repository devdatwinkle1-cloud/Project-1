type Props = { eyebrow?: string; title: string; description?: string; centered?: boolean; light?: boolean };

export default function SectionHeading({ eyebrow, title, description, centered = false, light = false }: Props) {
  return (
    <div className={`section-heading ${centered ? 'section-heading--center' : ''} ${light ? 'section-heading--light' : ''}`}>
      {eyebrow && <p className="eyebrow">{eyebrow}</p>}
      <h2>{title}</h2>
      <span className="heading-rule" aria-hidden="true" />
      {description && <p className="section-description">{description}</p>}
    </div>
  );
}