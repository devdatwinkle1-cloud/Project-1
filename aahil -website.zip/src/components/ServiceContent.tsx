import { Check } from 'lucide-react';
import type { Service } from '../data/site';
import Button from './Button';
import SmartImage from './SmartImage';

export default function ServiceContent({ service }: { service: Service }) {
  return (
    <article className="service-content" role="tabpanel" id="service-panel" aria-labelledby={`service-tab-${service.id}`} tabIndex={0}>
      <div className="service-content-image"><SmartImage src={service.image} alt={service.imageAlt} loading="eager" width={850} height={390} /></div>
      <div className="service-content-heading"><p className="eyebrow">Aahil Logistics</p><h2>{service.title}</h2><span className="heading-rule" aria-hidden="true" /></div>
      <h3 className="service-subtitle">{service.subtitle}</h3>
      {service.paragraphs.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
      <ul className="service-features">{service.features.map((feature) => <li key={feature}><Check size={17} aria-hidden="true" />{feature}</li>)}</ul>
      <Button to={`/contact?service=${service.id}`} arrow>Discuss Your Shipment</Button>
    </article>
  );
}