import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { Service } from '../data/site';

export default function ServicePreview({ service }: { service: Service }) {
  const Icon = service.icon;
  return (
    <Link className="service-preview" to={`/services?service=${service.id}`}>
      <Icon className="service-preview-icon" size={49} strokeWidth={1.3} aria-hidden="true" />
      <div className="service-preview-copy"><h3>{service.label}</h3><p>{service.short}</p><span className="service-preview-more">Read more<ArrowRight size={15} aria-hidden="true" /></span></div>
    </Link>
  );
}