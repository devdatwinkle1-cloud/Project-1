import { useState, type ImgHTMLAttributes } from 'react';
import { assets } from '../data/site';

type SmartImageProps = ImgHTMLAttributes<HTMLImageElement> & { fallback?: string };

export default function SmartImage({ src, fallback = assets.hero, alt, loading = 'lazy', ...props }: SmartImageProps) {
  const [failedSource, setFailedSource] = useState<string>();
  return (
    <img
      {...props}
      src={failedSource === src ? fallback : src}
      alt={alt}
      loading={loading}
      decoding="async"
      onError={() => setFailedSource(src)}
    />
  );
}