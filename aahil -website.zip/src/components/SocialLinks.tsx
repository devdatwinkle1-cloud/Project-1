const socialLinks = [
  {
    label: 'Visit Aahil Maritime on Facebook',
    href: 'https://www.facebook.com/people/Aahil-Shipping-Logistics-Pvt-Ltd/100076299372250/',
    path: 'M13.3 21v-8.2h2.8l.4-3.2h-3.2v-2c0-.9.3-1.6 1.6-1.6h1.7V3.1C16.3 3 15.3 3 14.2 3c-2.4 0-4 1.5-4 4.2v2.4H7.4v3.2h2.8V21h3.1Z',
  },
  {
    label: 'Share Aahil Maritime on Twitter',
    href: 'https://twitter.com/intent/tweet?text=Aahil%20Shipping%20%26%20Logistics&url=https%3A%2F%2Faahilshipping.com',
    path: 'M22 5.9a8.2 8.2 0 0 1-2.4.7 4.2 4.2 0 0 0 1.8-2.3 8.2 8.2 0 0 1-2.6 1 4.1 4.1 0 0 0-7 3.7 11.7 11.7 0 0 1-8.5-4.3 4.1 4.1 0 0 0 1.3 5.5 4 4 0 0 1-1.9-.5 4.1 4.1 0 0 0 3.3 4.1 4.1 4.1 0 0 1-1.8.1 4.1 4.1 0 0 0 3.8 2.8A8.2 8.2 0 0 1 2 18.4a11.6 11.6 0 0 0 17.9-9.8v-.5A8.3 8.3 0 0 0 22 5.9Z',
  },
  {
    label: 'Share Aahil Maritime on LinkedIn',
    href: 'https://www.linkedin.com/sharing/share-offsite/?url=https%3A%2F%2Faahilshipping.com',
    path: 'M5.3 3a2.3 2.3 0 1 0 0 4.6 2.3 2.3 0 0 0 0-4.6ZM3.4 9h3.8v12H3.4V9Zm6.2 0h3.6v1.6h.1A4 4 0 0 1 17 8.7c4 0 4.7 2.6 4.7 6V21h-3.8v-5.6c0-1.4 0-3.2-2-3.2s-2.4 1.5-2.4 3.1V21H9.6V9Z',
  },
];

export default function SocialLinks({ light = false }: { light?: boolean }) {
  return (
    <div className={`social-links ${light ? 'social-links--light' : ''}`} aria-label="Social media">
      {socialLinks.map((social) => (
        <a key={social.label} href={social.href} target="_blank" rel="noopener noreferrer" aria-label={social.label} title={social.label}>
          <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d={social.path} /></svg>
        </a>
      ))}
    </div>
  );
}