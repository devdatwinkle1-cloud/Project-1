import { useState } from 'react';
import { Quote } from 'lucide-react';
import { assets } from '../data/site';

const testimonials = [
  { quote: 'Aahil Maritime team members helped our company complete the shipment clearance and delivery to various Distribution Line sites.', name: 'Smith Shah' },
  { quote: 'Thank you for the great customer service. Have a great day!', name: 'Dinesh Aarya' },
];

export default function Testimonials() {
  const [active, setActive] = useState(0);
  return (
    <section className="testimonials">
      <div className="testimonials-map" style={{ backgroundImage: `url(${assets.map})` }} />
      <div className="container testimonials-inner">
        <p className="eyebrow">Our Happy Clients</p>
        <h2>What Our Clients Say</h2>
        <Quote className="testimonial-quote-icon" size={34} strokeWidth={1.5} aria-hidden="true" />
        <div className="testimonial-copy" key={active} aria-live="polite" aria-atomic="true">
          <blockquote>{testimonials[active].quote}</blockquote>
          <p className="testimonial-name">{testimonials[active].name}</p>
        </div>
        <div className="testimonial-dots" aria-label="Choose a testimonial">{testimonials.map((item, index) => <button key={item.name} onClick={() => setActive(index)} className={index === active ? 'is-active' : ''} aria-label={`Read testimonial by ${item.name}`} aria-pressed={index === active}><span /></button>)}</div>
      </div>
    </section>
  );
}