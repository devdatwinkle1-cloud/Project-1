import { Boxes, ClipboardCheck, Container, Plane, Ship, Snowflake, Truck } from 'lucide-react';

export const company = {
  name: 'AAHIL MARITIME PVT. LTD.',
  tagline: 'On Time, On Task, On the Move',
  email: 'info@aahilshipping.com',
  phone: '+91 22 4013 9773',
  phoneHref: 'tel:+912240139773',
  mobile: '+91 88981 44307',
  mobileHref: 'tel:+918898144307',
  address: 'Office No. 209, Skylark, Plot No. 63, Sector 11, CBD Belapur, Navi Mumbai - 400614, Maharashtra, India',
  introduction: 'AAHIL MARITIME PVT. LTD. is a full-service international freight forwarding and logistics company based in Navi Mumbai, INDIA, specializing in import, export and foreign-to-foreign global freight and logistics services including Ocean, Air, Land and Rail Freight, warehousing, NVOCC, project and heavy lift cargo, and customs brokerage services.',
};

export const navigation = [
  { label: 'Home', to: '/' },
  { label: 'About', to: '/about' },
  { label: 'Services', to: '/services' },
  { label: 'Contact Us', to: '/contact' },
];

export const assets = {
  logo: '/images/aahil-maritime.svg',
  footerLogo: '/images/aahil-maritime-light.svg',
  hero: '/images/cargo-hero.jpg',
  home: 'https://images.pexels.com/photos/6595780/pexels-photo-6595780.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200',
  about: 'https://images.pexels.com/photos/9806482/pexels-photo-9806482.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200',
  port: 'https://images.pexels.com/photos/20581299/pexels-photo-20581299.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200',
  map: 'https://aahilshipping.com/images/bg-image/map-bgimg.png',
  officeMap: 'https://images.pexels.com/photos/6876837/pexels-photo-6876837.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200',
  dubai: 'https://images.pexels.com/photos/13802297/pexels-photo-13802297.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200',
};

export const services = [
  {
    id: 'nvocc',
    title: 'NVOCC',
    label: 'NVOCC',
    image: 'https://images.pexels.com/photos/11820859/pexels-photo-11820859.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200',
    imageAlt: 'Ocean freight containers and shipping operations on modern vessel',
    icon: Container,
    short: 'Dependable container shipping, connecting your cargo to the world.',
    subtitle: 'Global connections. Dependable shipping.',
    paragraphs: [
      'As a Non-Vessel Operating Common Carrier, Aahil Maritime Pvt. Ltd. connects your business to international markets with reliable, efficient container shipping solutions.',
      'To achieve better performance, our team first identifies the critical obstacles to moving your cargo, then develops a coordinated approach to overcoming them. Our strong overseas network helps us manage your shipment from origin to destination with care and attention to detail.',
    ],
    features: ['Full Container Load (FCL)', 'Less than Container Load (LCL)', 'International agency network', 'End-to-end shipment coordination'],
  },
  {
    id: 'freight-forwarding',
    title: 'Freight Forwarding',
    label: 'FREIGHT FORWARDING',
    image: 'https://images.pexels.com/photos/3856433/pexels-photo-3856433.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200',
    imageAlt: 'International freight and shipping container terminal',
    icon: Ship,
    short: 'Seamless sea and air freight solutions, from origin to destination.',
    subtitle: 'Your cargo, connected across borders.',
    paragraphs: [
      'Aahil Maritime Pvt. Ltd. provides reliable, fast and quality freight forwarding services for sea and air cargo, including FCL and LCL sea freight consolidation.',
      'We bring together the right carriers, routes and local expertise for your shipment. From documentation and booking to coordination at destination, our team makes the journey simpler while keeping your time and cost requirements in focus.',
    ],
    features: ['Sea and air freight forwarding', 'FCL and LCL consolidation', 'Import and export coordination', 'Door-to-door delivery solutions'],
  },
  {
    id: 'air-freight',
    title: 'Air Freight',
    label: 'AIR FREIGHT',
    image: 'https://images.pexels.com/photos/36622441/pexels-photo-36622441.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200',
    imageAlt: 'Air cargo aircraft and freight handling at airport logistics hub',
    icon: Plane,
    short: 'Efficient air cargo services when every moment matters.',
    subtitle: 'Time-sensitive cargo. Expertly handled.',
    paragraphs: [
      'Freight forwarding is often a balancing act between time, cost and environmental considerations. That is one of the reasons companies choose Aahil Maritime Pvt. Ltd. for the cost-effective, smooth delivery of their cargo.',
      'Our air freight solutions offer a choice of speed, cost and flight frequency to suit your supply chain. We coordinate collection, airline bookings, documentation and delivery, with personal support throughout the journey.',
    ],
    features: ['International air cargo', 'Time-sensitive shipment handling', 'Airport-to-airport services', 'Import and export documentation'],
  },
  {
    id: 'custom-clearance',
    title: 'Custom Clearance',
    label: 'CUSTOM CLEARANCE',
    image: 'https://images.pexels.com/photos/36652827/pexels-photo-36652827.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200',
    imageAlt: 'Customs clearance and international cargo documentation at port',
    icon: ClipboardCheck,
    short: 'Experienced customs support for a smoother movement of goods.',
    subtitle: 'Clear guidance. Smooth clearance.',
    paragraphs: [
      'Aahil Maritime Pvt. Ltd. has its own CHA license and a dedicated team to perform customs-related work at significant Indian ports, for both air and sea cargo clearance.',
      'Our specialists help you navigate documentation and clearance requirements with an emphasis on accuracy and timely coordination. We work closely with your team to reduce avoidable delays and support the efficient release of your goods.',
    ],
    features: ['Air and sea cargo clearance', 'Import and export documentation', 'Customs process coordination', 'Dedicated clearance specialists'],
  },
  {
    id: 'transportation',
    title: 'Transportation',
    label: 'TRANSPORTATION',
    image: 'https://images.pexels.com/photos/2199293/pexels-photo-2199293.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200',
    imageAlt: 'Road freight container trucks transporting goods on highway',
    icon: Truck,
    short: 'Reliable inland transportation that keeps your business moving.',
    subtitle: 'Reliable movement, mile after mile.',
    paragraphs: [
      'Aahil Maritime Pvt. Ltd. is committed to meeting every customer\'s logistics requirements. By working directly with key carriers, we provide road and ground logistics services with competitive transit times and rates.',
      'Whether your cargo is moving to a port, a warehouse or its final destination, we coordinate the right transport for the job. Our team focuses on safe handling, dependable scheduling and clear communication.',
    ],
    features: ['Container transportation', 'First and last-mile coordination', 'Domestic road freight', 'Project and heavy lift cargo support'],
  },
  {
    id: 'warehousing',
    title: 'Warehousing',
    label: 'WAREHOUSING',
    image: 'https://images.pexels.com/photos/4487363/pexels-photo-4487363.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200',
    imageAlt: 'Organized modern warehouse storage and distribution facility',
    icon: Boxes,
    short: 'Flexible storage and distribution, built around your business.',
    subtitle: 'Space for your cargo. Support for your growth.',
    paragraphs: [
      'We offer dedicated and shared warehousing and distribution operations that accommodate the particular requirements of your business, along with smart value-added services that help improve performance.',
      'Our warehousing solutions connect storage with the rest of your supply chain. From receiving and handling to dispatch coordination, we help you manage the movement of your goods efficiently and with greater confidence.',
    ],
    features: ['Dedicated and shared storage', 'Inventory handling support', 'Distribution and dispatch', 'Value-added logistics services'],
  },
  {
    id: 'cold-chain',
    title: 'Cold Chain',
    label: 'COLD CHAIN',
    image: 'https://images.pexels.com/photos/27273657/pexels-photo-27273657.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200',
    imageAlt: 'Temperature-controlled refrigerated container logistics',
    icon: Snowflake,
    short: 'Carefully coordinated logistics for temperature-sensitive cargo.',
    subtitle: 'The right conditions, throughout the journey.',
    paragraphs: [
      'Temperature-controlled cargo, including flowers, seafood, processed food, fruits and pharmaceuticals, requires specialist handling. We coordinate its transportation through refrigerated containers, also known as reefers.',
      'Built on our ocean freight and logistics services, our cold chain solutions bring simplicity and predictability to the transport of your perishables. Talk to our team about the temperature, handling and timing requirements of your cargo.',
    ],
    features: ['Refrigerated container logistics', 'Perishable cargo handling', 'Temperature-sensitive shipments', 'Coordinated cold chain movement'],
  },
];

export type Service = (typeof services)[number];

export const dubaiOffice = {
  name: 'AAHIL SHIPPING LLC',
  address: 'Al Wasl R364, Office 408, Near Emirates Post, Al Karama, Dubai, United Arab Emirates',
  manager: 'Zahid Shingre',
  email: 'zahid.dxb@aahilshipping.com',
  phone: '+971 4 266 1868',
  phoneHref: 'tel:+97142661868',
  mobile: '+971 52 591 7012',
  mobileHref: 'tel:+971525917012',
};

export const branches = [
  { city: 'Mundra / Kandla / Hazira', address: 'Office No. 05, 1st Floor, OM Corner, Plot No. 336, 337 & 338, Ward 12/B, Gandhidham, Kutch - 370201, Gujarat, India' },
  { city: 'Nagpur', address: 'Flat No. 406, 4th Floor, Morya Apartment, Near Borkute Layout, Beside Narendra Nagar Ground, Nagpur - 440015' },
  { city: 'Kanpur', address: 'Office No. 19, Ground Floor, Kanpur Logistics Park Pvt. Ltd., Plot No. 5, Bhatta Area, Rani Gunj, Panki, Kanpur - 208020' },
  { city: 'Kolkata', address: 'M.A. Business Centre, Ground Floor, Suite 36, Poddar Point, 113 Park Street, Kolkata - 700016, India' },
];