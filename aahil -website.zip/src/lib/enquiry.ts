import { company, dubaiOffice, services } from '../data/site';

export type EnquiryValues = {
  name: string;
  email: string;
  phone: string;
  organization: string;
  service: string;
  branch: string;
  message: string;
  consent: boolean;
};

export type EnquiryErrors = Partial<Record<keyof EnquiryValues, string>>;

export function validateEnquiry(values: EnquiryValues): EnquiryErrors {
  const errors: EnquiryErrors = {};
  if (values.name.trim().length < 2) errors.name = 'Please enter your full name (at least 2 characters).';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(values.email.trim())) errors.email = 'Please enter a valid email address.';
  const phoneDigits = values.phone.replace(/\D/g, '');
  if (values.phone.trim() && (!/^[+()\d\s.-]+$/.test(values.phone) || phoneDigits.length < 7 || phoneDigits.length > 15)) errors.phone = 'Please enter a valid phone number, including the country code.';
  if (values.service !== 'general' && !services.some((service) => service.id === values.service)) errors.service = 'Please choose a service.';
  if (!['india', 'dubai'].includes(values.branch)) errors.branch = 'Please choose an office.';
  if (values.message.trim().length < 20) errors.message = 'Please tell us a little more (at least 20 characters).';
  if (values.message.length > 2000) errors.message = 'Please keep your message within 2,000 characters.';
  if (!values.consent) errors.consent = 'Please confirm that we may contact you about this enquiry.';
  return errors;
}

export function createEnquiry(values: EnquiryValues) {
  const recipient = values.branch === 'dubai' ? dubaiOffice.email : company.email;
  const service = services.find((item) => item.id === values.service)?.title || 'General Enquiry';
  const subject = `${service} enquiry - ${values.name.trim()}`;
  const body = [
    `Hello Aahil Maritime ${values.branch === 'dubai' ? 'Dubai' : 'Pvt. Ltd.'} team,`,
    '',
    values.message.trim(),
    '',
    `Name: ${values.name.trim()}`,
    `Email: ${values.email.trim()}`,
    ...(values.phone.trim() ? [`Phone: ${values.phone.trim()}`] : []),
    ...(values.organization.trim() ? [`Company: ${values.organization.trim()}`] : []),
    `Service: ${service}`,
    `Office: ${values.branch === 'dubai' ? 'Dubai, UAE' : 'Navi Mumbai, India'}`,
    '',
    'I consent to being contacted about this enquiry.',
  ].join('\n');
  return { recipient, subject, body, href: `mailto:${recipient}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}` };
}