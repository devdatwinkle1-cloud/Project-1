import { useEffect, useRef, useState, type KeyboardEvent } from 'react';
import { Clock3, Globe, ShieldCheck, Truck } from 'lucide-react';
import { assets, company } from '../data/site';
import PageBanner from '../components/PageBanner';
import SectionHeading from '../components/SectionHeading';
import SmartImage from '../components/SmartImage';
import Reveal from '../components/Reveal';
import Button from '../components/Button';

const principles = [
  { icon: Truck, title: 'Reliable Transportation', text: 'Dependable transportation, carefully coordinated to keep your supply chain moving.' },
  { icon: ShieldCheck, title: 'Safe Transportation', text: 'Safety is central to the way we work, with attentive door-to-door cargo handling.' },
  { icon: Clock3, title: 'Fast Transportation', text: 'Efficient routes and responsive service that put your delivery requirements first.' },
];

const statements = [
  { title: 'Vision', content: 'To provide the best customer experience, competitive pricing and be the top choice for our partners and customers worldwide for international freight forwarding and logistics services.' },
  { title: 'Mission', content: 'To deliver an exceptional customer experience through respect, integrity, reliability, professionalism, attention to detail and competitive pricing. We believe in effective communication, a passion for our work and a dedication to our partners and customers worldwide.' },
];

export default function About() {
  const [active, setActive] = useState(0);
  const [years, setYears] = useState(25);
  const yearsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = yearsRef.current;
    if (!el || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    let raf = 0;
    let started = false;
    const observer = new IntersectionObserver(([entry]) => {
      if (!entry.isIntersecting || started) return;
      started = true;
      const start = performance.now();
      const tick = (now: number) => {
        const progress = Math.min(1, (now - start) / 1200);
        setYears(Math.round(25 * (1 - Math.pow(1 - progress, 3))));
        if (progress < 1) raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
      observer.disconnect();
    }, { threshold: 0.4 });
    observer.observe(el);
    return () => { observer.disconnect(); cancelAnimationFrame(raf); };
  }, []);

  function handleStatementKey(event: KeyboardEvent<HTMLButtonElement>) {
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
    event.preventDefault();
    const next = event.key === 'Home' ? 0 : event.key === 'End' ? 1 : active === 0 ? 1 : 0;
    setActive(next);
    document.getElementById(`statement-tab-${next}`)?.focus();
  }

  return (
    <>
      <PageBanner title="About Us" image="/images/about-banner.jpg" photographic />
      <section className="section">
        <div className="container two-column about-intro">
          <Reveal className="about-image-wrap"><SmartImage src={assets.about} alt="Professional shipping and logistics operations" width={560} height={440} /><div className="experience-caption" ref={yearsRef}><Globe className="experience-globe" size={54} strokeWidth={1.6} aria-hidden="true" /><div className="experience-copy"><strong>{years}<span>+</span></strong><span>Years of<br />Industry Experience</span></div></div></Reveal>
          <Reveal delay={100}>
            <SectionHeading eyebrow="About Aahil Maritime Pvt. Ltd." title="Your Partner in Global Logistics" />
            <p>{company.introduction}</p>
            <p>We streamline our processes along the entire supply chain, focusing on sustainable progress and quality assurance to provide fast, efficient solutions and ensure long-term success.</p>
            <p>Our company-wide continuous improvement process is based on our commitment to our customers, our passion for innovation, and our firm belief in economical, ecological and social sustainability.</p>
            <Button to="/contact" arrow>Get in Touch</Button>
          </Reveal>
        </div>
      </section>
      <section className="section principles-section">
        <div className="container">
          <SectionHeading eyebrow="The Aahil Advantage" title="Transportation You Can Depend On" centered />
          <div className="principles-grid">{principles.map((principle, index) => <Reveal className="principle" delay={index * 65} key={principle.title}><principle.icon size={43} strokeWidth={1.4} aria-hidden="true" /><h3>{principle.title}</h3><p>{principle.text}</p></Reveal>)}</div>
        </div>
      </section>
      <section className="section vision-section">
        <div className="container two-column">
          <Reveal>
            <SectionHeading eyebrow="What Drives Us" title="A Commitment That Moves Us Forward" />
            <div className="statement-tabs" role="tablist" aria-label="Our vision and mission">{statements.map((statement, index) => <button id={`statement-tab-${index}`} key={statement.title} role="tab" aria-selected={active === index} aria-controls="statement-panel" tabIndex={active === index ? 0 : -1} onKeyDown={handleStatementKey} className={active === index ? 'is-active' : ''} onClick={() => setActive(index)}>Our {statement.title}</button>)}</div>
            <div className="statement-panel" role="tabpanel" id="statement-panel" aria-labelledby={`statement-tab-${active}`} tabIndex={0} key={active}><p>{statements[active].content}</p></div>
            <p className="vision-tagline">{company.tagline}</p>
          </Reveal>
          <Reveal delay={100} className="vision-photo"><SmartImage src={assets.port} alt="Global container transportation and logistics infrastructure" width={560} height={350} /></Reveal>
        </div>
      </section>
    </>
  );
}