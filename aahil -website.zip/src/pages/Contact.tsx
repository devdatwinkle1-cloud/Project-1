import { Mail, MapPin, Phone } from 'lucide-react';
import { Link } from 'react-router-dom';
import { branches, company, dubaiOffice } from '../data/site';
import PageBanner from '../components/PageBanner';
import SectionHeading from '../components/SectionHeading';
import ContactForm from '../components/ContactForm';
import LocationMap from '../components/LocationMap';
import Reveal from '../components/Reveal';

export default function Contact() {
  return (
    <>
      <PageBanner title="Contact Us" />
      <section className="section contact-section">
        <div className="container contact-layout">
          <div className="contact-offices">
            <SectionHeading eyebrow="We Are Here to Help" title="Get in Touch With Us" />
            <p className="contact-intro">A local team. A global network. Get in touch to discuss how we can move your business forward.</p>
            <div className="contact-office">
              <h3><MapPin size={21} aria-hidden="true" />HQ - Navi Mumbai</h3>
              <strong>{company.name}</strong>
              <address>{company.address}</address>
              <a href={company.mobileHref}><Phone size={15} aria-hidden="true" />{company.mobile}</a>
              <a href={company.phoneHref}><Phone size={15} aria-hidden="true" />{company.phone}</a>
              <a href={`mailto:${company.email}`}><Mail size={16} aria-hidden="true" />{company.email}</a>
            </div>
            <div className="contact-office">
              <h3><MapPin size={21} aria-hidden="true" />Dubai</h3>
              <strong>{dubaiOffice.name}</strong>
              <address>{dubaiOffice.address}</address>
              <a href={dubaiOffice.phoneHref}><Phone size={15} aria-hidden="true" />{dubaiOffice.phone}</a>
              <a href={dubaiOffice.mobileHref}><Phone size={15} aria-hidden="true" />{dubaiOffice.mobile}</a>
              <a href={`mailto:${dubaiOffice.email}`}><Mail size={16} aria-hidden="true" />{dubaiOffice.email}</a>
              <Link className="text-link contact-branch-link" to="/dubai-branch">View Dubai Branch</Link>
            </div>
            <div className="contact-office contact-office--last">
              <h3><MapPin size={21} aria-hidden="true" />Bangladesh</h3>
              <strong>AAHIL SHIPPING BANGLADESH LIMITED</strong>
              <address>Jane Alam Bhaban (2nd Floor), 253, Sk. Mujib Road, Agrabad C/A, Chittagong, Bangladesh.</address>
            </div>
          </div>
          <ContactForm />
        </div>
      </section>
      <section className="section presence-section">
        <div className="container">
          <SectionHeading eyebrow="Closer to Your Business" title="Our Presence" centered />
          <div className="branch-list">{branches.map((branch, index) => <Reveal key={branch.city} delay={index * 50}><MapPin size={24} strokeWidth={1.5} aria-hidden="true" /><h3>{branch.city}</h3><address>{branch.address}</address><a href={`mailto:${company.email}`}>{company.email}</a></Reveal>)}</div>
        </div>
      </section>
      <LocationMap address="Skylark Plot 63 Sector 11 CBD Belapur Navi Mumbai India" title="Find Our Head Office" />
    </>
  );
}