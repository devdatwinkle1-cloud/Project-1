import { Mail, MapPin, Phone, UserRound } from 'lucide-react';
import { assets, dubaiOffice } from '../data/site';
import PageBanner from '../components/PageBanner';
import SectionHeading from '../components/SectionHeading';
import SmartImage from '../components/SmartImage';
import Reveal from '../components/Reveal';
import Button from '../components/Button';
import LocationMap from '../components/LocationMap';

export default function DubaiBranch() {
  return (
    <>
      <PageBanner title="Dubai Branch" image={assets.dubai} />
      <section className="section dubai-intro">
        <div className="container two-column">
          <Reveal className="dubai-image"><SmartImage src="https://images.pexels.com/photos/10549884/pexels-photo-10549884.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200" alt="Shipping and freight operations serving Dubai and international destinations" width={560} height={560} /></Reveal>
          <Reveal delay={100}>
            <SectionHeading eyebrow="Our Dubai Branch" title="Aahil Shipping LLC" />
            <p>Your link to the Gulf and beyond. Our Dubai team brings local expertise and an international network together to meet your shipping and logistics requirements.</p>
            <p>From freight forwarding and NVOCC to air cargo, transportation, warehousing and cold chain, we coordinate your cargo with the care and personal attention it deserves.</p>
            <div className="branch-details">
              <div className="detail-row"><MapPin size={20} aria-hidden="true" /><address>{dubaiOffice.address}</address></div>
              <div className="detail-row"><UserRound size={19} aria-hidden="true" /><span><strong>{dubaiOffice.manager}</strong><span className="detail-small">Branch Manager</span></span></div>
              <div className="detail-row"><Phone size={18} aria-hidden="true" /><div><a href={dubaiOffice.phoneHref}>{dubaiOffice.phone}</a><span className="contact-separator"> / </span><a href={dubaiOffice.mobileHref}>{dubaiOffice.mobile}</a></div></div>
              <a className="detail-row" href={`mailto:${dubaiOffice.email}`}><Mail size={19} aria-hidden="true" /><span>{dubaiOffice.email}</span></a>
            </div>
            <Button to="/contact?branch=dubai" arrow>Contact Dubai Office</Button>
          </Reveal>
        </div>
      </section>
      <section className="section network-section">
        <div className="container">
          <SectionHeading eyebrow="Present Across the Globe" title="Our Network. Your Reach." description="Strong connections across established and emerging trade routes." centered />
          <div className="network-grid">
            <div><h3>Gulf &amp; Middle East</h3><p>Dubai, Sharjah, Dammam, Kuwait, Bahrain, Sohar, Doha and Umm Qasr.</p></div>
            <div><h3>India &amp; Asia</h3><p>Major Indian ports, Karachi, Singapore, Port Klang, Colombo and Chittagong.</p></div>
            <div><h3>Africa &amp; Red Sea</h3><p>Berbera, Sokhna, Aqaba, Port Sudan, Jeddah and Aden.</p></div>
          </div>
        </div>
      </section>
      <LocationMap address="Al Wasl R364 Al Karama Dubai United Arab Emirates" title="Visit Our Dubai Office" />
    </>
  );
}