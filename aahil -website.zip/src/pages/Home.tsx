import { ArrowRight, Globe2, MapPin, ShieldCheck, Ship } from 'lucide-react';
import { Link } from 'react-router-dom';
import { assets, company, services } from '../data/site';
import Hero from '../components/Hero';
import Button from '../components/Button';
import Reveal from '../components/Reveal';
import SectionHeading from '../components/SectionHeading';
import SmartImage from '../components/SmartImage';
import Testimonials from '../components/Testimonials';

const commitments = [
  { number: '01', title: 'Cargo', text: 'Our team of cargo experts is always available to help you with your shipment and answer your queries.' },
  { number: '02', title: 'Logistics Service', text: 'From freight transportation to distribution, we bring dependable logistics services together for your business.' },
  { number: '03', title: 'Project Cargo', text: 'Specialist coordination for complex, oversized and heavy lift cargo, nationally and internationally.' },
];

const highlights = [
  { icon: Ship, title: 'Ocean, Air & Road', text: 'One team for freight, clearance, transport and storage.' },
  { icon: ShieldCheck, title: 'Careful Handling', text: 'Documentation, timing and cargo care handled together.' },
  { icon: Globe2, title: 'India & Overseas', text: 'Local support from Navi Mumbai, Dubai and our network.' },
];

const offices = ['Navi Mumbai', 'Mundra', 'Kandla', 'Hazira', 'Ahmedabad', 'Raipur', 'Chennai', 'Dubai'];

export default function Home() {
  return (
    <>
      <Hero />

      <section className="home-stats" aria-label="Company highlights">
        <div className="container home-stats-grid">
          <div><strong>25+</strong><span>Years of Industry Experience</span></div>
          <div><strong>7</strong><span>Core Logistics Services</span></div>
          <div><strong>2</strong><span>Countries, One Network</span></div>
          <div><strong>On Time</strong><span>{company.tagline}</span></div>
        </div>
      </section>

      <section className="section home-about">
        <div className="container two-column intro-grid">
          <Reveal className="intro-photo">
            <SmartImage src={assets.home} alt="Container shipping and logistics operations at an international port" width={640} height={480} />
            <div className="intro-badge"><MapPin size={16} aria-hidden="true" /><span>Headquartered in Navi Mumbai</span></div>
          </Reveal>
          <Reveal delay={80} className="intro-copy">
            <SectionHeading eyebrow="About Aahil Maritime Pvt. Ltd." title="NVOCC Logistics and Transportation Service Provider" />
            <p>{company.introduction}</p>
            <p>We have been at the forefront of providing services to niche markets worldwide.</p>
            <div className="home-highlights">
              {highlights.map((item) => (
                <div key={item.title}>
                  <item.icon size={20} aria-hidden="true" />
                  <div><strong>{item.title}</strong><span>{item.text}</span></div>
                </div>
              ))}
            </div>
            <div className="home-about-actions">
              <Button to="/about" arrow>Read More</Button>
              <Link className="text-link" to="/contact">Talk to Our Team<ArrowRight size={16} aria-hidden="true" /></Link>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="section home-services">
        <div className="container">
          <Reveal>
            <SectionHeading eyebrow="What We Do" title="Our Services" description="Complete shipping and logistics solutions, tailored to your business." centered />
          </Reveal>
          <div className="home-service-grid">
            {services.map((service, index) => {
              const Icon = service.icon;
              return (
                <Reveal key={service.id} delay={(index % 3) * 50}>
                  <Link className="home-service-card" to={`/services?service=${service.id}`}>
                    <SmartImage src={service.image} alt={service.imageAlt} width={640} height={360} />
                    <span className="home-service-icon"><Icon size={22} aria-hidden="true" /></span>
                    <div>
                      <h3>{service.label}</h3>
                      <p>{service.short}</p>
                      <span>Read more<ArrowRight size={15} aria-hidden="true" /></span>
                    </div>
                  </Link>
                </Reveal>
              );
            })}
          </div>
          <div className="section-action"><Button to="/services" variant="navy" arrow>View All Services</Button></div>
        </div>
      </section>

      <section className="section commitments-section">
        <div className="container">
          <Reveal><SectionHeading eyebrow="Why Choose Aahil" title="Your Cargo. Our Commitment." centered /></Reveal>
          <div className="commitments-grid">
            {commitments.map((item, index) => (
              <Reveal key={item.number} delay={index * 60} className="commitment">
                <span className="commitment-number">{item.number}</span>
                <div><h3>{item.title}</h3><p>{item.text}</p></div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="home-network" aria-label="Office network">
        <div className="container home-network-inner">
          <div>
            <p className="eyebrow">Our Network</p>
            <h2>Closer to the ports that move your cargo.</h2>
          </div>
          <ul>
            {offices.map((office) => <li key={office}>{office}</li>)}
          </ul>
          <Button to="/dubai-branch" variant="outline">Dubai Branch</Button>
        </div>
      </section>

      <Testimonials />

      <section className="home-cta">
        <div className="container home-cta-inner">
          <div>
            <p>Ready to move your next shipment?</p>
            <h2>{company.tagline}</h2>
          </div>
          <div className="home-cta-actions">
            <Button to="/contact" arrow>Contact Us</Button>
            <Button to="/services" variant="outline">Explore Services</Button>
          </div>
        </div>
      </section>
    </>
  );
}
