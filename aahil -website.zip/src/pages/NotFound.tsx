import Button from '../components/Button';
import PageBanner from '../components/PageBanner';

export default function NotFound() {
  return <><PageBanner title="Page Not Found" /><section className="section not-found"><div className="container"><p className="eyebrow">404</p><h2>Let's get you back on course.</h2><p>The page you are looking for may have moved or no longer exists.</p><Button to="/" arrow>Back to Home</Button></div></section></>;
}