import { useEffect, type KeyboardEvent } from 'react';
import { ChevronRight } from 'lucide-react';
import { useSearchParams } from 'react-router-dom';
import { services } from '../data/site';
import PageBanner from '../components/PageBanner';
import SectionHeading from '../components/SectionHeading';
import ServiceContent from '../components/ServiceContent';

export default function Services() {
  const [params, setParams] = useSearchParams();
  const serviceId = params.get('service') || 'nvocc';
  const selected = services.find((service) => service.id === serviceId) || services[0];

  useEffect(() => {
    if (params.has('service') && !services.some((service) => service.id === serviceId)) {
      setParams({ service: 'nvocc' }, { replace: true, preventScrollReset: true });
    }
  }, [params, serviceId, setParams]);

  function selectService(id: string) {
    setParams({ service: id }, { preventScrollReset: true });
  }

  function handleTabKey(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    let next = index;
    if (event.key === 'ArrowDown') next = (index + 1) % services.length;
    else if (event.key === 'ArrowUp') next = (index - 1 + services.length) % services.length;
    else if (event.key === 'Home') next = 0;
    else if (event.key === 'End') next = services.length - 1;
    else return;
    event.preventDefault();
    selectService(services[next].id);
    document.getElementById(`service-tab-${services[next].id}`)?.focus();
  }

  return (
    <>
      <PageBanner title="Services" />
      <section className="section services-section">
        <div className="container">
          <SectionHeading eyebrow="Specialized Area" title="Our Services" centered />
          <div className="services-layout">
            <aside className="service-sidebar" aria-label="Choose a logistics service">
              <div className="service-tabs" role="tablist" aria-label="Logistics services" aria-orientation="vertical">
                {services.map((service, index) => <button key={service.id} id={`service-tab-${service.id}`} className={selected.id === service.id ? 'is-active' : ''} role="tab" aria-selected={selected.id === service.id} aria-controls="service-panel" tabIndex={selected.id === service.id ? 0 : -1} onClick={() => selectService(service.id)} onKeyDown={(event) => handleTabKey(event, index)}>{service.label}<ChevronRight size={17} aria-hidden="true" /></button>)}
              </div>
              <p className="service-sidebar-note">The right expertise.<br /><strong>For every shipment.</strong></p>
            </aside>
            <ServiceContent service={selected} key={selected.id} />
          </div>
        </div>
      </section>
    </>
  );
}